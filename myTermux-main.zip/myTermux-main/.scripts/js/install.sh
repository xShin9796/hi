pkg i -y nodejs
npm install node-fetch
npm install chalk
